from urllib.request import Request, urlopen
import gzip

req = Request('http://www.debian.org')
req.add_header('Accept-Encoding', 'gzip')
response = urlopen(req)

content = gzip.decompress(response.read())
result=content.splitlines()[:5]
print(result)