from urllib.request import Request, urlopen

req = Request('http://www.debian.org')
req.add_header('Accept-Language', 'de')
response = urlopen(req)

print(response.readlines()[:5])