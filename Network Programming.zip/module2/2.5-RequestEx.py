#Requests with urllib
from urllib.request import urlopen

response = urlopen('http://www.google.com')

print(response)

text=str(response.read())
print(text)

with open("output.html", "w") as f:
        f.write(text) 