from urllib.request import urlopen

response = urlopen('http://www.google.com')
print(response)

input("\nPress Enter to continue...\n")

print(response.readline())
print(response.readline())
