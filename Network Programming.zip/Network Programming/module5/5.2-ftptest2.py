import ftplib

filename = "myfile.txt"

ftp = ftplib.FTP("192.168.3.78")
ftp.login("gcman","password")
ftp.cwd('Downloads')
ftp.dir()

#download
file = open(filename ,'wb')
ftp.retrbinary("RETR " + filename ,file.write)
file.close()

ftp.quit()
