# Upload
import ftplib

ftp = ftplib.FTP("192.168.3.78")
ftp.login("gcman","password")
ftp.cwd('Downloads')
ftp.dir()
print("\n")

# Upload
ftp.encoding = "utf-8"
local_filename = "/Users/gcman/Downloads/Cameras-Long.txt"
dest_filename = "Cameras-Long.txt"
with open(local_filename, "rb") as file:
    ftp.storbinary(f"STOR {dest_filename}", file)
 
ftp.dir()
ftp.quit()
