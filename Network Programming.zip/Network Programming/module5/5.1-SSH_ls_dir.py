import paramiko
import time
 
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
try:
        ssh.connect('192.168.3.78', username='gcman', password='password')
except paramiko.SSHException:
        print("Connection Failed")
        quit()
 
stdin,stdout,stderr = ssh.exec_command("cd Downloads && ls -l")
# stdin,stdout,stderr = ssh.exec_command("pwd")
time.sleep(5)
 
for line in stdout.readlines():
        print(line.strip())
ssh.close()