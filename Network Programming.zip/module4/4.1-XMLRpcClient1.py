import xmlrpc.client

# with xmlrpc.client.ServerProxy("http://localhost:8000/") as proxy:
#     print("3 is even: %s" % str(proxy.is_even(3)))
#     print("100 is even: %s" % str(proxy.is_even(100)))

proxy = xmlrpc.client.ServerProxy("http://192.168.3.76:8000/")
print("3 is even: %s" % str(proxy.is_even(3)))
print("100 is even: %s" % str(proxy.is_even(100)))
print("12 is even: %s" % str(proxy.is_even(12)))
print("123 is even: %s" % str(proxy.is_even(123)))